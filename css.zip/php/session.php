<?php 
session_name("shop");
session_start();?>